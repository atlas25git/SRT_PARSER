#include "SubtitleParser.h"

vector<CSubtitleElement*> CSubtitleParser::GetSubtitles()
{
	return m_SubtitlesCollection;
}

CSubtitleParser::CSubtitleParser(void)
{

}

CSubtitleParser::~CSubtitleParser(void)
{
}